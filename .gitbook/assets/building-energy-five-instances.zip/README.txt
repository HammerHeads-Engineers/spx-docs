SPX Connections: five-instance building energy example

Open building-energy-five-instances.json through Connections > Import configuration
on a disposable SPX workspace with capacity for five models and five instances.
Import models, instances and connections. Start all five instances, then start
the Connections container. This restores configuration, not live values/time.
It replaces runtime configuration; export your current system first.
Use Fit graph to view and drag nodes to arrange the graph as needed.

Source: HammerHeads-Engineers/spx-examples (MIT), commit
be71a161e97eb7a112d0581136a7b702b34cd98a.
Models: weather_gateway_wago_pfc200__vaisala_wxt530__mqtt, building_physics,
pv_physics_lux, smart_plug__matter, cerbo_gx_ess__modbus.
Modifications: protocol blocks removed; demo defaults set to 5 degC and 48000 lux,
smart plug ON at 1500 W, EV load zero. All power connections use watts.
This is a simplified teaching simulation. No MQTT, Matter or Modbus transport
is started and no physical device communication is claimed.

Screenshot/runtime: SPX UI and Server 1.0.0-rc.76, SDK 1.0.0-rc.21.
Two weather cases were exercised and all seven connections propagated values.
Balance: pv_power_w + battery_power_w + grid_power_w = load_power_w.
Positive battery power = discharge; positive grid power = import.
A snapshot restores model defaults, not the screenshot's instantaneous values.
